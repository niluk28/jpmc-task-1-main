# JPMC Task 1
Starter repo for task 1 of the JPMC software engineering program
